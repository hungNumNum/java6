package com.demo.app;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import com.demo.bean.Student;

public class Lambda {
	static List<Student> students = Arrays.asList(
			new Student("Nam", true, 9.0),
			new Student("Nam", false, 4.0),
			new Student("Nam", true, 6.0)
			);
	
	public static void main(String[] args) {
		demo4();
	}

	private static void demo4() {
		Demo4Inter inter = x ->System.out.println(x);
		inter.m1(20222);
	}

	private static void demo3() {
		Collections.sort(students,(sv1,sv2) -> sv1.getMark().compareTo(sv2.getMark()));
		students.forEach(sv ->{
			System.out.println("Ten:" + sv.getName());
			System.out.println("Gender:" + sv.getGender());
			System.out.println("Mark:" + sv.getMark());
		});
	}

	private static void demo2() {
		students.forEach(sv ->{
			System.out.println("Ten:" + sv.getName());
			System.out.println("Gender:" + sv.getGender());
			System.out.println("Mark:" + sv.getMark());
		});
		
	}

	private static void demo1() {
		List<Integer> list = Arrays.asList(1,2,3,4,55);
		list.forEach(n ->System.out.println(n));
	}
	
}
@FunctionalInterface
 interface Demo4Inter{
	 void m1(int x);
	 default void m2() {};
	 public static void m3() {};
 }

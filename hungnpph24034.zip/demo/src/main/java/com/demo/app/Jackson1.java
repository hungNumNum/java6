package com.demo.app;

public class Jackson1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

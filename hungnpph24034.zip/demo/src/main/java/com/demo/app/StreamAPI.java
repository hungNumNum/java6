package com.demo.app;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.demo.bean.Student;

public class StreamAPI {
	
	static List<Student> students = Arrays.asList(
			new Student("Nam", true, 9.0),
			new Student("ha", false, 4.0),
			new Student("Hung", true, 6.0)
			);
	public static void main(String[] args) {
		demo3();
	}

	private static void demo4() {
		Double double1 = students.stream()
				.mapToDouble(sv -> sv.getMark())
				.average().getAsDouble();
		System.out.println("average " + double1);
		
		 double sum = students.stream()
				 .mapToDouble(sv -> sv.getMark())
				 .sum();
		 System.out.println("sum " + sum);
		 
		 double min_mark = students.stream()
				 .mapToDouble(sv -> sv.getMark())
				 .min().getAsDouble();
		 System.out.println("min " + min_mark);
				
		 boolean all_passed = students.stream()
				 .allMatch(sv -> sv.getMark() >= 5);
		 System.out.println("all_passed " + all_passed);
		 
		 Student min_sv = students.stream()
				 .reduce(students.get(0),(min, sv) -> sv.getMark() < min.getMark() ? sv:min);
		 System.out.println("Name " + min_sv.getName());
	}

	private static void demo3() {
		List<Student> list = students.stream()
				.filter(t -> t.getMark()>5)
				.peek(t -> t.setName(t.getName().toUpperCase()))
				.collect(Collectors.toList());
		list.forEach(n -> System.out.println(n));
		
	}

	private static void demo2() {
		List<Integer> list = Arrays.asList(1,4,6,10,11,15);
		List<Double> list2 = list.stream()
							.filter(t -> t % 2==0)
							.map(s -> Math.sqrt(s))
							.peek(t -> System.out.println(t))
							.collect(Collectors.toList());
		
	}

	private static void demo1() {
		Stream<Integer> stream1 = Stream.of(1,2,4,6);
		stream1.forEach(n -> System.out.println(n));
 		
		List<Integer> list = Arrays.asList(1,6,8,9); 
		list.stream().forEach(n -> System.out.println(n));
	}
}
